# Coletor Scribd → PDF para GitHub Codespaces

Interface web: abra a porta encaminhada, cole a URL de um documento Scribd e acompanhe o progresso. O Chromium executa em modo headless dentro do Codespace; não é necessário abrir o Chrome no servidor.

## Requisitos

- GitHub Codespaces baseado em Linux e Node.js 20+ (a configuração incluída usa Node 22).
- Acesso legítimo ao documento e à página pública que será carregada pelo navegador remoto.

## Instalação num Codespace existente

Na raiz do projeto (onde está `package.json`), execute:

```bash
npm install
npx playwright install --with-deps chromium
npm start
```

Se o terminal disser que a porta 3000 foi encaminhada automaticamente, abra a aba **PORTS** e clique no endereço da porta 3000. Se não aparecer, adicione a porta `3000` manualmente.

## Uso

1. Na página web, cole a URL do documento, normalmente `https://www.scribd.com/document/ID/titulo`.
2. Clique em **Iniciar coleta e gerar PDF**.
3. A página acompanhará o progresso, URLs, telas, lacunas aproximadas e revisões.
4. Quando terminar, o download do PDF é iniciado automaticamente. Também fica disponível o botão **Baixar PDF**.

O PDF é montado no servidor com as imagens baixadas por meio do Chromium/Playwright e não abre uma janela de impressão.

## Limitações importantes

- O Codespace não compartilha a sessão já autenticada do seu Chrome pessoal. Se o documento exigir login, assinatura, CAPTCHA ou uma autorização que não esteja disponível para o Chromium remoto, o processo pode falhar. O app não contorna login, assinatura nem verificações de acesso.
- O padrão de URL de imagem foi preservado: host `html.scribd.com`, caminho `/images/` e nome numérico.
- A numeração dos arquivos pode conter lacunas legítimas; o contador é apenas uma estimativa.
- Se algumas imagens forem recusadas pelo servidor, o PDF pode ser gerado parcialmente e a interface mostrará quantas falharam.
- O Codespace serve o app em `0.0.0.0` para permitir o encaminhamento de portas. Mantenha a porta 3000 como **Private** e não a torne pública.
- O arquivo PDF e os temporários são guardados por até uma hora e depois apagados automaticamente.

## Instalação automática para novos Codespaces

A pasta `.devcontainer/devcontainer.json` encaminha a porta 3000 e instala as dependências, incluindo Chromium, quando o container é criado. Em um Codespace já existente, use os comandos de instalação acima ou reconstrua o container depois de adicionar a configuração.
