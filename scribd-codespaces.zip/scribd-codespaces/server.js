'use strict';

const express = require('express');
const { chromium } = require('playwright');
const PDFDocument = require('pdfkit');
const sharp = require('sharp');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MAX_PAGES = 5000;
const MAX_TELAS = 10000;
const TELAS_POR_LOTE = 5;
const ESPERA_TELA = 120;
const ESPERA_INICIAL = 1800;
const ESPERA_FINAL = 800;
const MAX_REVISOES = 2;
const MAX_TENTATIVAS_FINAL = 5;
const CHECK_IMAGES = 20;
const CHECK_SCREENS_MARGIN = 10;
const ALLOWED_IMAGE_HOST = 'html.scribd.com';
const jobs = new Map();
let activeJobId = null;

app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public'), { etag: true, maxAge: 0 }));

function addLog(job, message) {
  const time = new Date().toLocaleTimeString('pt-BR', { hour12: false });
  job.logs.push(`${time} — ${message}`);
  if (job.logs.length > 120) job.logs.splice(0, job.logs.length - 120);
  console.log(`[${job.id}] ${message}`);
}

function validateDocumentUrl(value) {
  if (typeof value !== 'string' || value.length > 2000) {
    throw new Error('Informe a URL completa do documento.');
  }
  let url;
  try { url = new URL(value); } catch { throw new Error('A URL informada não é válida.'); }
  if (url.protocol !== 'https:') throw new Error('Use uma URL HTTPS do Scribd.');
  if (!['www.scribd.com', 'scribd.com'].includes(url.hostname.toLowerCase())) {
    throw new Error('Informe uma URL de www.scribd.com ou scribd.com.');
  }
  if (!/^\/document\/\d+(?:\/|$)/i.test(url.pathname)) {
    throw new Error('A URL deve ser a página de um documento Scribd, normalmente /document/ID/titulo.');
  }
  url.hash = '';
  return url.href;
}

function parseImageUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.hostname.toLowerCase() !== ALLOWED_IMAGE_HOST || !url.pathname.includes('/images/')) return null;
    const filename = decodeURIComponent(url.pathname.split('/').pop());
    const match = filename.match(/^(\d+)(?=[._-])/);
    if (!match) return null;
    const number = Number(match[1]);
    if (!Number.isSafeInteger(number) || number < 0) return null;
    return { number, url: url.href };
  } catch { return null; }
}

function getGaps(urlMap) {
  if (!urlMap.size) return [];
  const nums = [...urlMap.keys()];
  const min = Math.min(...nums);
  const max = Math.max(...nums);
  // Protege o processo contra identificadores muito dispersos.
  if (max - min > 100000) return [];
  const present = new Set(nums);
  const missing = [];
  for (let n = min; n <= max; n++) if (!present.has(n)) missing.push(n);
  return missing;
}

function updateProgress(job, page, state, detail) {
  job.state = state;
  if (detail) job.detail = detail;
  job.screens = job.screens || 0;
  if (page && !page.isClosed()) {
    job.percent = page.evaluate(() => {
      const max = Math.max(document.documentElement.scrollHeight - innerHeight, 1);
      return Math.min(99, Math.round(scrollY / max * 100));
    }).then(value => { job.percent = value; }).catch(() => {});
  }
}

async function collectFromPage(page, urlMap, positions) {
  let totalAdded = 0;
  for (const frame of page.frames()) {
    let values;
    try {
      values = await frame.evaluate(() => {
        const found = new Set();
        for (const item of performance.getEntriesByType('resource')) found.add(item.name);
        for (const el of document.querySelectorAll('img,source,[src],[orig],[data-src],[data-original]')) {
          if (el.currentSrc) found.add(el.currentSrc);
          for (const attr of ['src','orig','data-src','data-original','data-lazy-src','data-url']) {
            const value = el.getAttribute(attr);
            if (value) {
              try { found.add(new URL(value, location.href).href); } catch {}
            }
          }
        }
        return [...found];
      });
    } catch { continue; }

    let scrollY = 0;
    try { scrollY = await frame.evaluate(() => window.scrollY); } catch {}
    for (const value of values || []) {
      const item = parseImageUrl(value);
      if (!item) continue;
      if (!urlMap.has(item.number) && urlMap.size < MAX_PAGES) {
        urlMap.set(item.number, item.url);
        positions.set(item.number, scrollY);
        totalAdded++;
      }
    }
  }
  return totalAdded;
}

async function clickSkipAd(page, job) {
  let clicked = false;
  for (const frame of page.frames()) {
    try {
      const result = await frame.evaluate(() => {
        const selectors = 'button,a,[role="button"],input[type="button"],input[type="submit"],[aria-label],[title]';
        for (const el of document.querySelectorAll(selectors)) {
          const text = String(el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().replace(/\s+/g, ' ');
          if (!/^(skip\s*ad|skip advertisement|pular anúncio|pular anuncio)$/i.test(text)) continue;
          const rect = el.getBoundingClientRect();
          const style = getComputedStyle(el);
          if (rect.width > 0 && rect.height > 0 && rect.width <= 500 && rect.height <= 150 && style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
            el.click();
            return text;
          }
        }
        return null;
      });
      if (result) {
        clicked = true;
        addLog(job, `Botão de anúncio disponível clicado: ${result}.`);
      }
    } catch {}
  }
  if (clicked) await page.waitForTimeout(ESPERA_FINAL).catch(() => {});
  return clicked;
}

async function scrollInfo(page) {
  return page.evaluate(() => ({
    y: window.scrollY,
    height: Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0),
    viewport: window.innerHeight
  }));
}

async function downloadImage(context, url, referer, outputPath, numero) {
  const response = await context.request.get(url, {
    headers: {
      'Referer': referer,
      'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
    },
    timeout: 30000,
    failOnStatusCode: false
  });
  if (!response.ok()) throw new Error(`HTTP ${response.status()}`);

  const finalUrl = new URL(response.url());
  if (finalUrl.protocol !== 'https:' || finalUrl.hostname.toLowerCase() !== ALLOWED_IMAGE_HOST || !finalUrl.pathname.includes('/images/')) {
    throw new Error('o endereço final não é uma imagem permitida do Scribd');
  }
  const headers = response.headers();
  const contentType = String(headers['content-type'] || '').toLowerCase();
  if (contentType.includes('text/html')) throw new Error('o servidor devolveu HTML em vez de imagem; pode exigir autenticação');

  const body = await response.body();
  if (!body.length) throw new Error('a imagem veio vazia');
  if (body.length > 50 * 1024 * 1024) throw new Error('a imagem excede 50 MB');

  await sharp(body, { failOn: 'error' })
    .rotate()
    .flatten({ background: '#ffffff' })
    .jpeg({ quality: 92, mozjpeg: true })
    .toFile(outputPath);
  return outputPath;
}

async function createPdf(files, outputPath) {
  const doc = new PDFDocument({ size: 'A4', margin: 0, autoFirstPage: false, compress: true, bufferPages: false });
  const stream = fs.createWriteStream(outputPath);
  doc.pipe(stream);
  const pageW = 595.28;
  const pageH = 841.89;
  const padding = 22;
  const finished = new Promise((resolve, reject) => {
    stream.on('finish', resolve);
    stream.on('error', reject);
    doc.on('error', reject);
  });

  for (const file of files) {
    doc.addPage({ size: 'A4', margin: 0 });
    const meta = await sharp(file).metadata();
    const scale = Math.min((pageW - padding * 2) / meta.width, (pageH - padding * 2) / meta.height);
    const width = meta.width * scale;
    const height = meta.height * scale;
    doc.image(file, (pageW - width) / 2, (pageH - height) / 2, { width, height });
  }
  doc.end();
  await finished;
}

async function doCollect(job, documentUrl) {
  const workDir = await fsp.mkdtemp(path.join(os.tmpdir(), 'scribd-codespaces-'));
  job.workDir = workDir;
  let browser;
  let context;

  try {
    job.status = 'running';
    job.state = 'Abrindo Chromium oculto';
    job.detail = 'Acessando a URL informada...';
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
    context = await browser.newContext({
      viewport: { width: 1365, height: 900 },
      locale: 'pt-BR',
      userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Safari/537.36'
    });
    const page = await context.newPage();
    page.setDefaultNavigationTimeout(60000);
    page.setDefaultTimeout(15000);

    const urlMap = new Map();
    const positions = new Map();
    let screens = 0;
    let batches = 0;
    let revisions = 0;
    let imagesAtCheck = 0;
    let nextImageCheck = CHECK_IMAGES;
    let screensAtCheck = 0;
    let finalReached = false;

    job.state = 'Carregando documento';
    job.detail = documentUrl;
    addLog(job, 'Navegando para o documento informado.');
    const response = await page.goto(documentUrl, { waitUntil: 'domcontentloaded', timeout: 60000 });
    if (response && response.status() >= 400) throw new Error(`O Scribd respondeu com HTTP ${response.status()} ao abrir o documento.`);
    await page.waitForTimeout(ESPERA_INICIAL);

    if (/\/login(?:\/|\?|$)/i.test(page.url())) {
      throw new Error('O Scribd redirecionou para login. O Chromium do Codespace não compartilha a sessão do seu Chrome pessoal. Este app não contorna login ou assinatura.');
    }
    const pageText = await page.locator('body').innerText({ timeout: 5000 }).catch(() => '');
    if (/verify you are human|checking your browser|captcha/i.test(pageText.slice(0, 5000))) {
      throw new Error('O Scribd mostrou uma verificação de acesso. O app não tenta contornar essa verificação.');
    }

    let added = await collectFromPage(page, urlMap, positions);
    addLog(job, `Página carregada; ${urlMap.size} URLs de imagem encontradas inicialmente.`);
    let stableBottomChecks = 0;
    let lastHeight = 0;
    let lastCount = urlMap.size;
    let screensWithoutAdCheck = 0;

    while (screens < MAX_TELAS) {
      const beforeCount = urlMap.size;
      const beforeInfo = await scrollInfo(page);
      const startY = beforeInfo.y;
      const step = Math.max(beforeInfo.viewport * 0.95, 500);
      let atBottom = false;

      for (let i = 1; i <= TELAS_POR_LOTE && screens < MAX_TELAS; i++) {
        const info = await scrollInfo(page);
        const destination = Math.min(startY + step * i, Math.max(0, info.height - info.viewport));
        await page.evaluate(y => window.scrollTo(0, y), destination);
        await page.waitForTimeout(ESPERA_TELA);
        const newCount = await collectFromPage(page, urlMap, positions);
        added += newCount;
        screens++;
        screensWithoutAdCheck++;
        imagesAtCheck += newCount;

        if (urlMap.size >= nextImageCheck || imagesAtCheck >= CHECK_IMAGES || screensWithoutAdCheck >= CHECK_SCREENS_MARGIN) {
          job.state = 'Verificando anúncio e coletando';
          const didClick = await clickSkipAd(page, job);
          if (didClick) {
            await page.waitForTimeout(ESPERA_FINAL);
            added += await collectFromPage(page, urlMap, positions);
          }
          imagesAtCheck = 0;
          nextImageCheck = urlMap.size + CHECK_IMAGES;
          screensWithoutAdCheck = 0;
        }

        job.screens = screens;
        job.images = urlMap.size;
        job.gaps = getGaps(urlMap).length;
        const current = await scrollInfo(page);
        job.percent = Math.min(99, Math.round(current.y / Math.max(current.height - current.viewport, 1) * 100));
        job.state = `Coletando — lote ${batches + 1}`;
        job.detail = `${TELAS_POR_LOTE} telas por lote · ${urlMap.size} URLs encontradas`;

        if (current.y + current.viewport >= current.height - 5) {
          atBottom = true;
          break;
        }
      }

      batches++;
      const afterCount = urlMap.size;
      const afterInfo = await scrollInfo(page);
      job.detail = `Lote ${batches} concluído · ${afterCount} URLs · ${getGaps(urlMap).length} possíveis lacunas`;
      addLog(job, `Lote ${batches}: +${afterCount - beforeCount} URLs; total ${afterCount}; ${getGaps(urlMap).length} possíveis lacunas.`);

      if (atBottom || afterInfo.y + afterInfo.viewport >= afterInfo.height - 5) {
        job.state = 'Verificando o final do documento';
        await page.waitForTimeout(ESPERA_FINAL);
        const oldHeight = afterInfo.height;
        const oldSize = urlMap.size;
        await collectFromPage(page, urlMap, positions);
        await clickSkipAd(page, job);
        await page.waitForTimeout(300);
        const freshInfo = await scrollInfo(page);
        if (freshInfo.height > oldHeight || urlMap.size > oldSize) {
          stableBottomChecks = 0;
          continue;
        }
        stableBottomChecks++;
        if (stableBottomChecks >= MAX_TENTATIVAS_FINAL) {
          finalReached = true;
          break;
        }
      } else if (afterCount === lastCount && afterInfo.height === lastHeight) {
        // Continua tentando como o coletor original; o limite total impede loop infinito.
      }
      lastCount = afterCount;
      lastHeight = afterInfo.height;
    }

    // Revisão de lacunas, mantendo a estratégia original de voltar a posições aproximadas.
    for (let round = 1; round <= MAX_REVISOES; round++) {
      const gaps = getGaps(urlMap);
      if (!gaps.length || !urlMap.size) break;
      revisions = round;
      job.revisions = revisions;
      job.state = `Revisão ${round}/${MAX_REVISOES}`;
      addLog(job, `Revisão ${round}: ${gaps.length} possíveis lacunas.`);
      const maxNum = Math.max(...urlMap.keys());
      const info = await scrollInfo(page);
      const destinations = new Set();
      for (const n of gaps) {
        const y = positions.has(n) ? positions.get(n) : Math.round((n / Math.max(maxNum, 1)) * info.height);
        destinations.add(Math.max(0, y - info.viewport));
        destinations.add(Math.max(0, y));
      }
      for (const y of [...destinations].sort((a, b) => a - b)) {
        await page.evaluate(dest => window.scrollTo(0, dest), y);
        await page.waitForTimeout(ESPERA_TELA);
        await collectFromPage(page, urlMap, positions);
        screens++;
        if (screens % CHECK_SCREENS_MARGIN === 0) await clickSkipAd(page, job);
        job.screens = screens;
        job.images = urlMap.size;
        job.gaps = getGaps(urlMap).length;
        job.percent = 100;
      }
    }

    await collectFromPage(page, urlMap, positions);
    if (!urlMap.size) {
      const body = await page.locator('body').innerText().catch(() => '');
      throw new Error('Nenhuma imagem numerada encontrada. O Scribd pode exigir login, ter mudado a estrutura ou não carregar imagens neste documento. ' + body.slice(0, 200));
    }

    job.images = urlMap.size;
    job.screens = screens;
    job.gaps = getGaps(urlMap).length;
    job.revisions = revisions;
    job.state = 'Baixando imagens e montando PDF';
    job.detail = `Preparando ${urlMap.size} imagens em ordem numérica...`;
    job.percent = 100;
    addLog(job, `Coleta encerrada: ${urlMap.size} URLs; ${job.gaps} possíveis lacunas; final estabilizado: ${finalReached}.`);

    const sorted = [...urlMap.entries()].sort((a, b) => a[0] - b[0]);
    if (sorted.length > MAX_PAGES) throw new Error(`O limite é ${MAX_PAGES} imagens por PDF.`);
    const filesByNumber = new Map();
    const failed = [];
    let completed = 0;
    let cursor = 0;
    const workerCount = Math.min(4, sorted.length);
    const workers = Array.from({ length: workerCount }, async () => {
      while (true) {
        const index = cursor++;
        if (index >= sorted.length) return;
        const [number, imageUrl] = sorted[index];
        const file = path.join(workDir, `page_${String(number).padStart(8, '0')}.jpg`);
        try {
          await downloadImage(context, imageUrl, page.url(), file, number);
          filesByNumber.set(number, file);
        } catch (error) {
          failed.push({ number, message: error.message });
          addLog(job, `Imagem ${number} não pôde ser baixada: ${error.message}`);
        }
        completed++;
        job.detail = `Baixando imagens: ${completed}/${sorted.length}`;
      }
    });
    await Promise.all(workers);

    const files = [...filesByNumber.entries()].sort((a, b) => a[0] - b[0]).map(item => item[1]);
    if (!files.length) {
      const first = failed[0];
      throw new Error(`Nenhuma imagem pôde ser baixada. ${first ? `Primeira falha: imagem ${first.number}: ${first.message}.` : ''} O acesso pode depender de uma sessão que o Codespace não possui.`);
    }

    job.state = 'Gerando PDF';
    job.detail = `Montando PDF com ${files.length} imagens...`;
    job.pdfPath = path.join(workDir, 'scribd.pdf');
    await createPdf(files, job.pdfPath);
    job.pdfPages = files.length;
    job.failedImages = failed.length;
    job.warning = failed.length
      ? `PDF gerado parcialmente: ${failed.length} de ${sorted.length} imagens não puderam ser baixadas. Confira os registros antes de confiar na completude do documento.`
      : `Todas as ${files.length} imagens selecionadas foram incorporadas ao PDF.`;
    job.status = 'done';
    job.state = 'PDF pronto para baixar';
    job.detail = `PDF concluído · ${files.length} imagens incluídas`;
    job.percent = 100;
    addLog(job, `PDF criado com ${files.length} imagens; falhas: ${failed.length}.`);

    // Retém o arquivo para download e remove os arquivos temporários depois de uma hora.
    setTimeout(async () => {
      try { await fsp.rm(workDir, { recursive: true, force: true }); } catch {}
      jobs.delete(job.id);
    }, 60 * 60 * 1000).unref();
  } catch (error) {
    job.status = 'error';
    job.error = error.message || 'Erro desconhecido durante a coleta.';
    job.state = 'Falha';
    job.detail = 'Consulte a mensagem de erro.';
    addLog(job, `Falha: ${job.error}`);
    if (workDir) {
      try { await fsp.rm(workDir, { recursive: true, force: true }); } catch {}
      job.workDir = null;
    }
  } finally {
    if (context) await context.close().catch(() => {});
    if (browser) await browser.close().catch(() => {});
    if (activeJobId === job.id) activeJobId = null;
  }
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'Scribd Codespaces PDF Collector' }));

app.post('/api/jobs', (req, res) => {
  let documentUrl;
  try { documentUrl = validateDocumentUrl(req.body?.url); }
  catch (error) { return res.status(400).json({ error: error.message }); }

  if (activeJobId) {
    const active = jobs.get(activeJobId);
    if (active && active.status === 'running') {
      return res.status(409).json({ error: 'Já existe uma coleta em andamento. Aguarde terminar antes de iniciar outra.' });
    }
  }

  const id = crypto.randomUUID();
  const job = {
    id,
    status: 'running',
    state: 'Na fila',
    detail: 'Iniciando...',
    percent: 0,
    images: 0,
    screens: 0,
    gaps: 0,
    revisions: 0,
    logs: [],
    pdfPath: null,
    pdfPages: 0,
    failedImages: 0,
    warning: '',
    error: null
  };
  jobs.set(id, job);
  activeJobId = id;
  res.status(202).json({ id, status: 'running' });
  doCollect(job, documentUrl).catch(error => {
    job.status = 'error';
    job.error = error.message || 'Erro ao executar a coleta.';
    if (activeJobId === id) activeJobId = null;
  });
});

app.get('/api/jobs/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Coleta não encontrada ou já expirada.' });
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    id: job.id,
    status: job.status,
    state: job.state,
    detail: job.detail,
    percent: job.percent,
    images: job.images,
    screens: job.screens,
    gaps: job.gaps,
    revisions: job.revisions,
    logs: job.logs,
    pdfPages: job.pdfPages,
    failedImages: job.failedImages,
    warning: job.warning,
    error: job.error
  });
});

app.get('/api/jobs/:id/pdf', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job || job.status !== 'done' || !job.pdfPath || !fs.existsSync(job.pdfPath)) {
    return res.status(404).type('text').send('O PDF ainda não está disponível ou já expirou.');
  }
  res.download(job.pdfPath, 'scribd.pdf', error => {
    if (error) console.error(`[${job.id}] Falha no envio do PDF:`, error.message);
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Scribd PDF Collector ativo em http://localhost:${PORT}`);
  console.log('Abra a aba PORTS do Codespaces e acesse a URL encaminhada da porta 3000.');
  console.log('Mantenha a porta privada. O app deve ser usado apenas pelo proprietário do Codespace.');
});
